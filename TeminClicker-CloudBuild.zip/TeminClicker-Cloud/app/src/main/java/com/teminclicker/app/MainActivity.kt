package com.teminclicker.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.ceil

class MainActivity : Activity() {
    private var coins = 0L
    private var total = 0L
    private var power = 1L
    private var auto = 0L
    private var powerCost = 25L
    private var autoCost = 100L

    private lateinit var coinsText: TextView
    private lateinit var totalText: TextView
    private lateinit var powerText: TextView
    private lateinit var cpsText: TextView
    private lateinit var upgrade: Button
    private lateinit var autoButton: Button
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("save", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
        updateUi()
        val timer = android.os.Handler(mainLooper)
        timer.post(object : Runnable {
            override fun run() {
                if (auto > 0) { coins += auto; total += auto; updateUi(); save() }
                timer.postDelayed(this, 1000)
            }
        })
    }

    private fun tv(text: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(8, 8, 8, 8)
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18,18,22))
        }

        root.addView(tv("ТЁМИН КЛИКЕР", 28f, true))
        coinsText = tv("", 40f, true)
        root.addView(coinsText)
        totalText = tv("", 13f)
        root.addView(totalText)

        val coin = Button(this).apply {
            text = "🪙"
            textSize = 64f
            setOnClickListener { coins += power; total += power; updateUi() }
        }
        root.addView(coin, LinearLayout.LayoutParams(-1, 230).apply { setMargins(0,16,0,16) })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        powerText = tv("", 18f, true)
        cpsText = tv("", 18f, true)
        stats.addView(powerText, LinearLayout.LayoutParams(0,70,1f))
        stats.addView(cpsText, LinearLayout.LayoutParams(0,70,1f))
        root.addView(stats)

        upgrade = Button(this)
        upgrade.setOnClickListener {
            if (coins >= powerCost) {
                coins -= powerCost; power++; powerCost = ceil(powerCost * 1.65).toLong()
                status.text = "Сила клика улучшена 🔥"; updateUi(); save()
            } else status.text = "Не хватает монет 😈"
        }
        root.addView(upgrade, LinearLayout.LayoutParams(-1,90))

        autoButton = Button(this)
        autoButton.setOnClickListener {
            if (coins >= autoCost) {
                coins -= autoCost; auto++; autoCost = ceil(autoCost * 1.8).toLong()
                status.text = "Автокликер куплен 🤖"; updateUi(); save()
            } else status.text = "Нужно больше монет 💰"
        }
        root.addView(autoButton, LinearLayout.LayoutParams(-1,90))

        val saveButton = Button(this).apply {
            text = "💾 Сохранить"
            setOnClickListener { save(); status.text = "Сохранено 💾" }
        }
        root.addView(saveButton, LinearLayout.LayoutParams(-1,70))

        status = tv("Кликай по монете, Тём 👆", 14f)
        root.addView(status)
        setContentView(root)
    }

    private fun updateUi() {
        if (!::coinsText.isInitialized) return
        coinsText.text = "$coins 🪙"
        totalText.text = "Всего заработано: $total"
        powerText.text = "За клик: $power"
        cpsText.text = "В секунду: $auto"
        upgrade.text = "⚡ Сила клика\nЦена: $powerCost 🪙"
        autoButton.text = "🤖 Автокликер\nЦена: $autoCost 🪙"
    }

    private fun save() {
        prefs.edit().apply {
            putLong("coins", coins); putLong("total", total); putLong("power", power)
            putLong("auto", auto); putLong("powerCost", powerCost); putLong("autoCost", autoCost)
        }.apply()
    }

    private fun load() {
        coins = prefs.getLong("coins", 0); total = prefs.getLong("total", 0)
        power = prefs.getLong("power", 1); auto = prefs.getLong("auto", 0)
        powerCost = prefs.getLong("powerCost", 25); autoCost = prefs.getLong("autoCost", 100)
    }
}
