# Тёмин Кликер

Android-кликер с монетой, улучшением силы клика, автокликером и сохранением прогресса.

## Сборка
Открой проект в Android Studio и выполни:
`./gradlew assembleDebug`

APK появится в:
`app/build/outputs/apk/debug/app-debug.apk`

Проект использует стандартный Gradle/Android project layout.


## Logo
The generated game logo is included as `res/drawable/temin_clicker_logo.png` and is used as the Android launcher icon.


## Cloud build (no computer)
This project includes `.github/workflows/build-apk.yml`.
After uploading the project to GitHub, open **Actions → Build Temin Clicker APK** and run the workflow.
The finished `app-debug.apk` is uploaded as the `TeminClicker-APK` artifact.
